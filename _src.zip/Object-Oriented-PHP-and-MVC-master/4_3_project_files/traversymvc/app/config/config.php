<?php
  // App Root
  define('APPROOT', dirname(dirname(__FILE__)));
  // URL Root
  define('URLROOT', 'http://localhost/traversymvc');
  // Site Name
  define('SITENAME', 'TraversyMVC');