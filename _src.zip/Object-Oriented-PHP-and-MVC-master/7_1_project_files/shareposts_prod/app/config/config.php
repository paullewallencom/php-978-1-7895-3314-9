<?php
  // DB Params
  define('DB_HOST', 'localhost');
  define('DB_USER', '');
  define('DB_PASS', '');
  define('DB_NAME', '');

  // App Root
  define('APPROOT', dirname(dirname(__FILE__)));
  // URL Root
  define('URLROOT', 'http://YOURDOMAIN');
  // Site Name
  define('SITENAME', 'SharePosts');
  // App Version
  define('APPVERSION', '1.0.0');